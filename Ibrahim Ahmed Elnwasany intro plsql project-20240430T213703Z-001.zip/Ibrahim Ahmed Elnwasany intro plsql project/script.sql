create or replace procedure ibrahem_installments_proc as
  v_added_months number(2);
  v_installment_date date;
  v_installment_count number;
begin
  for contracts_record in (select * from contracts) loop
    if contracts_record.contract_payment_type = 'ANNUAL' then
      v_added_months := 12;
    elsif contracts_record.contract_payment_type = 'HALF_ANNUAL' then
      v_added_months := 6;
    elsif contracts_record.contract_payment_type = 'QUARTER' then
      v_added_months := 3;
    elsif contracts_record.contract_payment_type = 'MONTHLY' then
      v_added_months := 1;
    end if;

    v_installment_date := contracts_record.contract_startdate;
    v_installment_count := 0;

    loop
      insert into installments_paid (installment_id, contract_id, installment_date, installment_amount, paid)
      values (installments_paid_seq.nextval, contracts_record.contract_id, v_installment_date, 0, 0);

      v_installment_date := add_months(v_installment_date, v_added_months);
      v_installment_count := v_installment_count + 1;

      if v_installment_date = contracts_record.contract_enddate then
        exit;
      end if;
    end loop;

    update installments_paid
    set installment_amount = (contracts_record.contract_total_fees - nvl(contracts_record.contract_deposit_fees, 0)) / v_installment_count
    where contract_id = contracts_record.contract_id;
  end loop;
end ibrahem_installments_proc;
/
